## 1. Balance
    - 1.1 Are employees able to maintain work life balance?
    - 1.2 Do employees feel empowered to exercise flexible working patterns?

## 2. Flexibility
    - 2.1 Are employees embracing a flexible working schedule?
    - 2.2 What are the most common working patterns?

## 3. Resilience
    - 3.1 Are employees able to manage uninterrupted focus time?
    - 3.2 Can teams respond to urgent needs without risking employee wellbeing?

## 4. Community
    - 4.1 Do employees feel a sense of belonging and community?
    - 4.2 Are employees receiving enough coaching?


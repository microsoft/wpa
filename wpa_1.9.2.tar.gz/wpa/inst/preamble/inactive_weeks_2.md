You can easily remove inactive weeks from your dataset by using the function `identify_inactiveweeks(return = "data_cleaned")`.


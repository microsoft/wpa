## Overview

In this report, you will find a series of summary and analysis relating to key **connectivity** metrics in Workplace Analytics, including external/internal network size vs breadth. 

For full metric definitions, please visit our [official documentation](https://docs.microsoft.com/en-us/workplace-analytics/use/metric-definitions).

---

If you believe abnormal Outlook settings are distorting your results, consider standardizing working hours across your analysis population. You can override Outlook settings by setting a global parameter in the _Dependencies_ section of the Person query.  

 



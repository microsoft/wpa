
Organizational data is descriptive information about the employees in your organization, such as the employee's organization, job function, level, etc. This data has been uploaded by your organization's Workplace Analytics Administrator.  The quality of this information is important as it enables Workplace Analytics to attribute Office 365 data to specific groups, and slice the collaboration data in different ways to uncover relevant trends for your organization.  



This section can help you understand the population scope for your analysis and validate the size of your selected grouping based on your business knowledge. Please note that this report will use *Organization* as the default grouping, but you can specify another attribute of your choosing as the `hrvar` input of the function `validation_report()`. Please note that a minimum threshold has not been applied to this section, providing a full list of attributes for your review.  
 


Workplace Analytics uses the working days and hours settings from each measured **Microsoft 365 Exchange** mailbox to calculate collaboration metrics. This data allows the system to distinguish between collaboration activity (email, meetings, and Teams calls & IMs) that takes place during and outside of working hours.  

The most frequent working hours set in Outlook in this dataset are the following:  


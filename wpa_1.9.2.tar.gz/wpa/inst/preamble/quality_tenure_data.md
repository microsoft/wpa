
When the employee's *HireDate* is available as an organizational data attribute, it can be used to calculate tenure of employees. This section does a quality check on the calculated tenure field, calculated as the employee's last weekly collaboration date in your query minus the *HireDate*. The findings of the plot below will shed light on your analysis population's tenure distribution.   


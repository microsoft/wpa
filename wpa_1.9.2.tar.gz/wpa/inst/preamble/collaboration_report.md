## Overview

In this report, you will find a series of summary and analysis relating to key **collaboration** metrics in Workplace Analytics, including email and meeting hours. 

For full metric definitions, please visit our [official documentation](https://docs.microsoft.com/en-us/workplace-analytics/use/metric-definitions).

---

